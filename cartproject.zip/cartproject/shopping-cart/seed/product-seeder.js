var Product= require('../models/product');

var mongoose=require('mongoose');
mongoose.connect('mongodb://localhost:27017/shoppie',{ useNewUrlParser: true });
var products=
[
    new Product(
    {
        imagepath:'https://jamesclear.com/wp-content/uploads/2017/04/The-Kite-Runner-by-Khaled-Hosseini-444x700.jpg',
        title:'kite runner',
        description:'best novel',
        price:12
    }),

    new Product(
        {
            imagepath:'https://jamesclear.com/wp-content/uploads/2017/04/A-Thousand-Splendid-Suns-by-Khaled-Hosseini-456x700.gif',
            title:'A thousand splendid suns',
            description:'best novel',
            price:12
        }),

    new Product(
            {
                imagepath:'https://jamesclear.com/wp-content/uploads/2017/04/The-Poisonwood-Bible-by-Barbara-Kingsolver-445x700.jpg',
                title:' The poision wood bible',
                description:'best novel',
                price:12
            }),
     new Product(
                {
                    imagepath:'https://jamesclear.com/wp-content/uploads/2017/04/The-Poisonwood-Bible-by-Barbara-Kingsolver-445x700.jpg',
                    title:' Akhil Sangubotla',
                    description:'good novel',
                    price:15
                })        
            

        
];

var done=0;

for( var i=0;i<products.length;i++)
{
    products[i].save(function(err,result){
        if(err)
        console.error(err);
        done++;
        if(done==products.length)
        {
            exit();
        }
    });
}

function exit( ){
    mongoose.disconnect();
}