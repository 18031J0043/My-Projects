var express = require('express');
var router = express.Router();
 var product = require('../models/product');
var Cart=require('../models/cart');
 
var csrf=require('csurf');
var passport=require('passport');

 var csrfProtection=csrf();
 router.use(csrfProtection);


/* GET home page. */
router.get('/', function(req, res, next) {
  
  product.find(function (err,docs){
      var productChunks=[];
      var chunkSize=3;
    
      for(var i=0;i<docs.length;i+=chunkSize){
        productChunks.push(docs.slice(i,i+chunkSize));
      }
    res.render('shops/index', { title: 'Shopping Cart', products:productChunks});
  });
  
});

router.get('/add-to-cart/:id',function(req,res,next){
  var productId=req.params.id;
  var cart= new Cart(req.session.cart ? req.session.cart:{});

  product.findById(productId,function(err,product){
    if(err){
      return res.redirect('/');
    }
    cart.add(product,product.id);
    req.session.cart=cart;
    //console.log(req.session.cart);
    res.redirect('/');

  });
});

  router.get('/shopping-cart',function(req,res,next){
    if(!req.session.cart){
      return res.render('shop/shopping-cart',{products:null});
    
    }
    var cart=new Cart(req.session.cart);
    res.render('shops/shopping-cart',{products:cart.generateArray(),totalPrice:cart.totalPrice})
  });


  router.get('/checkout',function(req,res,next){
    if(!req.session.cart){
      return res.redirect('/shopping-cart');
    }
    var cart = new Cart (req.session.cart);
    res.render('shops/checkout',{total:cart.totalPrice});
  });

  router.get('/admin/signup',function(req,res,next){
    var messages=req.flash('error');
    res.render('admin/signup',{csrfToken:req.csrfToken(),messages:messages,hasErrors:messages.length>0});
  });
  
  router.post('/admin/signup',passport.authenticate('local.signup',{
    successRedirect:'/admin/profile',
    failureRedirect:'/admin/signup',
    failureFlash:true
  
  }));
  
  router.get('/admin/profile',function(req,res,next){
    res.render('admin/profile');
  });
  
  router.get('/admin/signin',function(req,res,next){
    var messages=req.flash('error');
    res.render('admin/signin',{csrfToken:req.csrfToken(),messages:messages,hasErrors:messages.length>0});
  });

  router.post('/admin/signin',passport.authenticate('local.signin',{
    successRedirect:'/admin/profile',
    failureRedirect:'/admin/signin',
    failureFlash:true
  }));
  
  module.exports = router;
  
  