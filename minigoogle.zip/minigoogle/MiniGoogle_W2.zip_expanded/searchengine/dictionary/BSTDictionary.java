package searchengine.dictionary;

import java.util.ArrayList;

class TreeNode <K extends Comparable<K>, V>
{ 
    K key;
    V value;
    TreeNode left, right; 

    public TreeNode(K key ,V value) { 
       this.key= key;
       this.value=value;
       
        left = right = null; 
    } 
} 

class BST <K extends Comparable<K>, V>
{
  
	TreeNode root; 
    int count;
    String st[]=new String[count];
  
    BST() {  
        root = null;  
        count=0;
    } 
  
    
    void insert(K key,V value) { 
    	count++;
    	System.out.println(count);
       root = insertRec(root, key,value); 
    } 
      
    
    TreeNode insertRec(TreeNode root, K key,V value) { 
  
       
        if (root == null) 
        { 
            root = new TreeNode(key,value); 
            return root; 
        } 
       
       int k= key.compareTo ((K) (root.key));
        
        if (k<0) 
            root.left = insertRec(root.left, key,value); 
        else if(k>0) 
            root.right = insertRec(root.right, key,value); 

        return root; 
    } 
    public String[] inorderbe()
	{
	ArrayList<K> al=new ArrayList<K>();
	inorderbe(root,al);
	int size=al.size();
	String [] s=new String[size];
	for(int i=0;i<size;i++)
	{
		s[i]=(String)al.get(i);
	}
	
	return s;
		
	}
	public void inorderbe(TreeNode n,ArrayList al)
	{
		/*if(n==null)
			return;
		else
		{
			*/
		if(n!=null) {
		inorderbe(n.left,al);
		
		/*if(n.key!=null) {
			st[i]=(String) n.key;
			i++;}*/
		al.add(n.key);
			
		
		inorderbe(n.right,al);
	
		}
	
	
}
    void deleteKey(K key) 
    { count--;
        root = deleteRec(root, key); 
    } 
    TreeNode deleteRec(TreeNode root, K key) 
    { 
        
        if (root == null)  return root; 
        int k=key.compareTo((K) root.key);
        
        if (k<0) 
            root.left = deleteRec(root.left, key); 
        else if (k>0) 
            root.right = deleteRec(root.right, key); 
  
        else
        { 
            
            if (root.left == null) 
                return root.right;
            else if (root.right == null) 
                return root.left; 
  
            root.key = minValue(root.right); 
 
            root.right = deleteRec(root.right, (K) root.key); 
        } 
  
        return root; 
    } 
  
    K minValue(TreeNode root) 
    { 
        K minv = (K) root.key; 
        while (root.left != null) 
        { 
            minv = (K) root.left.key; 
            root = root.left; 
        } 
        return minv; 
    } 
   
   
    public V get( K key) {
		return (V)  get(root,key);
	}
	
	public V get(TreeNode x, K key) { 
	if (x == null) {
		
		return null;}
	int cmp =key.compareTo((K) x.key) ;  
	if (cmp < 0) 
	return get(x.left, key);     
	else if (cmp > 0) 
	return get(x.right, key);   
	else return (V) x.value; 
	
	}
}
public class BSTDictionary <K extends Comparable<K>, V> implements DictionaryInterface <K,V>
{
	BST b=new BST();
	@Override
	public K[] getKeys() {
		// TODO Auto-generated method stub
		b.inorderbe();
		return (K[]) b.inorderbe();
	}

	@Override
	public V getValue(K str) {
		// TODO Auto-generated method stub
		return (V) b.get(str);
	}

	@Override
	public void insert(K key, V value) {
		// TODO Auto-generated method stub
		b.count++;
		b.insert(key, value);
		
	}

	@Override
	public void remove(K key) {
		b.count--;
		// TODO Auto-generated method stub
		b.deleteKey(key);
		
	}



}



