package searchengine.dictionary;

import java.util.ArrayList;
import java.util.Vector;

class HashNode <K extends Comparable<K>, V>
{
    K key;
    V value;
    
    public HashNode(K key, V value )
    {
    	this.key=key;
    	this.value=value;
    }
}   


public class MyHashDictionary <K extends Comparable<K>, V> implements DictionaryInterface <K,V>{

	
	
	HashNode[] a= new HashNode[1000];
	int count=0;
	@Override
	public K[] getKeys() {
		// TODO Auto-generated method stub
		
		String ar[]=new String[count];
		int i=0;
		for(int j=0;j<a.length;j++)
		{
			if(a[j]!=null &&a[j].key!=null)
			{
				ar[i]=(String) a[j].key;
				i++;
			}
		}
		
		return (K[]) ar;
	}

	@Override
	public V getValue(K str) {
		// TODO Auto-generated method stub
		int id=hashcode(str);
		return (V) a[id].value;
	}

	@Override
	public void insert(K key, V value) {
		// TODO Auto-generated method stub
		HashNode<K,V> hn=new HashNode<K,V>(key,value);
		int ind=hashcode(key);
		if(a[ind]==null)
		{
			count++;
		}
		a[ind]=hn;
		
	}

	@Override
	public void remove(K key) {
		// TODO Auto-generated method stub
		int ind=hashcode(key);
		a[ind]=null;
		count--;
	}

	public int hashcode(K key)
	{
		String ab=(String) key;
		int sum=0;
		for(int i=0;i<ab.length();i++)
		{
			sum=sum+(ab.charAt(i)*(i+1));
		}
		sum=sum% a.length;
		return sum;
	}
}
