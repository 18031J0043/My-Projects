package searchengine.dictionary;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;

public class HashDictionary <K extends Comparable<K>, V> implements DictionaryInterface <K,V>{
	Hashtable<K,V> h=new Hashtable<K,V>();

	@Override
	public K[] getKeys() {
		Iterator<K> m= (Iterator<K>) h.keys();
		// TODO Auto-generated method stub
	String aa[]=new String[h.size()];int i=0;
	while(m.hasNext())
	{
		aa[i]=(String) m.next();
		i++;
	}
		return (K[]) aa;
	}

	@Override
	public V getValue(K str) {
	
		return h.get(str);
	}

	@Override
	public void insert(K key, V value) {
		// TODO Auto-generated method stub
		h.put(key, value);
	}

	@Override
	public void remove(K key) {
		// TODO Auto-generated method stub
		h.remove(key);
	}

}
