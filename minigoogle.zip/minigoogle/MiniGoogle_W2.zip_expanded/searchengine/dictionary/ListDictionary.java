package searchengine.dictionary;

class Node <K extends Comparable<K>, V>
{
	K Key;
	V Value;
	Node next;
	public Node(K key, V value)
	{
		
		Key = key;
		Value = value;	
	}
	  

}

class LList <K extends Comparable<K>, V>
{
	Node head;
	String k[];
	public LList() 
	{
		
		head=null;
	}
	public void pushend(K key, V value)
	{
		Node n=new Node(key,value);
		if(head==null)
		{
			head=n;
		}
		else
		{
		
		Node temp =head;
		
		while(temp.next!=null)
		{
			temp=temp.next;
		}
		
		temp.next=n;
		}
	}
	public void pushfront(K key, V value)
	{
		Node n=new Node(key,value);
		Node temp=head;
		if(getvalue(key)!=null)
		{
			push(key,value);
		}
		else
		{
		if(head==null)
		{
			head=n;
		}
		else
		{
		n.next=head;
		head=n;
		}
		}
					
	}
	
	
	
	
	
	public void popatlast()
	{
		Node temp=head;
		Node sec=null;
		if(head==null)
		{
			System.out.println("no node in list");
		}
		 if(head.next==null)
		{
			Comparable ele=head.Key;
			head=null;
			
		}
		else
		{
		while(temp.next!=null)
		{
			sec = temp;
			temp = temp.next;
			
		}
		sec.next = null;
		
		

		}
	}
	
	public K popatfront()
	{
		
		if(head==null)
		{
			System.out.print("Steque is empty.");
			return null;
			
		}
		else
			{
			
			if(head.next==null)
			{
				K ele1=(K) head.Key;
				head=null;
				return ele1;
			}
		
			 K ele=(K) head.Key;
			 head=head.next;
			return ele;
		 
			}
		
		
	}
	
	
	public V getvalue(K key)
	{
		
		if(head==null)
		{
			System.out.println(" list is empty");
			return null;
		}
		else
		{
		Node temp=head;
		while(temp!=null )
		{
			if(temp.Key.compareTo(key)==0)
				return (V) temp.Value;
			
			temp=temp.next;
		}
						return null;
		}	
	}
	
	public K[] getkeys()
	{
		k=new String[size()];
		Node temp=head;
		       
	
		for(int i=0;temp!=null;i++)
		{
			k[i]=(String) temp.Key;
			temp=temp.next;
		}
		//return (K[]) k;
		return (K[]) k;
		
		
	}
	
	
	
	
	public int size()
	{	int count=0;
		Node temp=head;
		while(temp!=null)
		{
			temp=temp.next;
			count=count+1;
			
		}
		//System.out.println(count);
		return count;
	}
	public void  pop(K key1)
	 {
		
	      Node temp=head;
			if(head.Key.compareTo(key1)==0)
			{
				head=temp.next;
			}
			while(temp.next!=null )
			{
				if(temp.next.Key.compareTo(key1)==0)
				{
					temp.next=temp.next.next;
					break;
				}
				temp=temp.next;
			}
			
	}
	public void  push(K key1,V value)
	 {
		
	      Node temp=head;
			if(head.Key.compareTo(key1)==0)
			{
				head=temp.next;
			}
			while(temp.next!=null )
			{
				if(temp.next.Key.compareTo(key1)==0)
				{
					temp.next.Value=value;
					break;
				}
				temp=temp.next;
			}
	 }
	
}

public class ListDictionary <K extends Comparable<K>, V> implements DictionaryInterface <K,V>{

	LList list=new LList();
	
	@Override
	public K[] getKeys() 
	{
		
		// TODO Auto-generated method stub
		
		return (K[]) list.getkeys();
			

	}

	@Override
	public V getValue(K str) {
		// TODO Auto-generated method stub
		
		
		return (V) list.getvalue(str);

	}

	@Override
	public void insert(K key, V value) 
	{
		// TODO Auto-generated method stub
	
		list.pushfront(key, value);
		
	}

	@Override
	public void remove(K key) {
		// TODO Auto-generated method stub
		
		list.pop(key);
		
	}

}
