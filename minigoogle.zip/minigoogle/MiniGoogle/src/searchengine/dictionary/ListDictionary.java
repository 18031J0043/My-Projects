package searchengine.dictionary;

import java.util.ArrayList;

class Value
{
	int count;
	String url;
	public Value(int count, String url) 
	{
		
		this.count = count;
		this.url = url;
	}
	
	
}
class Node 
{
	String Key;
	ArrayList<Value>ppr=new ArrayList<Value>();;
	Node next;
	public Node(String key, Object value)
	{
		
		Key = key;
		Value kk=new Value(1,(String) value);
		ppr.add(kk);
			
	}
}

class LList
{
	Node head;
	String k[];
	public LList() 
	{
		
		head=null;
	}
	
	public void pushfront(String key, Object value)
	{
		Node n=new Node(key,value);
		Node temp=head;
		if(getvalue(key)!=null)
		{
			push(key,value);
		}
		else
		{
		if(head==null)
		{
			head=n;
		}
		else
		{
		n.next=head;
		head=n;
		}
		}
					 
	}
	

	public Object getvalue(String key)
	{
		
		if(head==null)
		{
			System.out.println(" list is empty");
			return null;
		}
		else
		{
		Node temp=head;
		while(temp!=null )
		{
			if(temp.Key.compareTo(key)==0)
				return (Object) temp.ppr;
			
			temp=temp.next;
		}
						return null;
		}	
	}
	
	public String[] getkeys()
	{
		k=new String[size()];
		Node temp=head;
		       
	
		for(int i=0;temp!=null;i++)
		{
			k[i]=(String) temp.Key;
			temp=temp.next;
		}
		//return (String[]) k;
		return (String[]) k;
		
		
	}
	
	
	
	
	public int size()
	{	int count=0;
		Node temp=head;
		while(temp!=null)
		{
			temp=temp.next;
			count=count+1;
			
		}
		//System.out.println(count);
		return count;
	}
	public void  pop(String key1)
	 {
		
	      Node temp=head;
			if(head.Key.compareTo(key1)==0)
			{
				head=temp.next;
			}
			while(temp.next!=null )
			{
				if(temp.next.Key.compareTo(key1)==0)
				{
					temp.next=temp.next.next;
					break;
				}
				temp=temp.next;
			}
			
	}
	public void  push(String key1,Object value)
	 {
		
	      Node temp=head;
	      
			if(head.Key.compareTo(key1)==0)
			{
				int cou=0;
				for(int i=0;i<head.ppr.size();i++)
				{
					String sval=head.ppr.get(i).url;
					if(sval.equals(value))
					{
						cou=1;
						head.ppr.get(i).count++;
						
					}
				}
			}
			while(temp.next!=null )
			{
				if(temp.next.Key.compareTo(key1)==0)
				{
					temp.next.ppr=(ArrayList<Value>) value;
					break;
				}
				temp=temp.next;
			}
	 }
	
}

public class ListDictionary  implements DictionaryInterface 
{

	LList list=new LList();
	
	@Override
	public String[] getKeys() 
	{
		
		// TODO Auto-generated method stub
		
		return (String[]) list.getkeys();
			

	}

	@Override
	public Object getValue(String str) {
		// TODO Auto-generated method stub
		
		return (Object) list.getvalue(str);
	}

	@Override
	public void insert(String key, Object value) 
	{
		// TODO Auto-generated method stub
	
		list.pushfront(key, value);
		
	}

	@Override
	public void remove(String key) {
		// TODO Auto-generated method stub
		
		list.pop(key);
		
	}

}
