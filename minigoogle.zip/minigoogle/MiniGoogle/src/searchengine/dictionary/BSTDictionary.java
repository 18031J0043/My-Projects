package searchengine.dictionary;

import java.util.ArrayList;

class TreeNode 
{ 
    String key;
    Object value;
    TreeNode left, right; 

    public TreeNode(String key ,Object value) { 
       this.key= key;
       this.value=value;
       
        left = right = null; 
    } 
} 

class BST 
{
  
	TreeNode root; 
    int count;
    String st[]=new String[count];
  
    BST() {  
        root = null;  
        count=0;
    } 
  
    
    void insert(String key,Object value) { 
    	count++;
    	System.out.println(count);
       root = insertRec(root, key,value); 
    } 
      
    
    TreeNode insertRec(TreeNode root, String key,Object value) { 
  
       
        if (root == null) 
        { 
            root = new TreeNode(key,value); 
            return root; 
        } 
       
       int k= key.compareTo ((String) (root.key));
        
        if (k<0) 
            root.left = insertRec(root.left, key,value); 
        else if(k>0) 
            root.right = insertRec(root.right, key,value); 

        return root; 
    } 
    public String[] inorderbe()
	{
	ArrayList<String> al=new ArrayList<String>();
	inorderbe(root,al);
	int size=al.size();
	String [] s=new String[size];
	for(int i=0;i<size;i++)
	{
		s[i]=(String)al.get(i);
	}
	
	return s;
		
	}
	public void inorderbe(TreeNode n,ArrayList al)
	{
		/*if(n==null)
			return;
		else
		{
			*/
		if(n!=null) {
		inorderbe(n.left,al);
		
		/*if(n.key!=null) {
			st[i]=(String) n.key;
			i++;}*/
		al.add(n.key);
			
		
		inorderbe(n.right,al);
	
		}
	
	
}
    void deleteKey(String key) 
    { count--;
        root = deleteRec(root, key); 
    } 
    TreeNode deleteRec(TreeNode root, String key) 
    { 
        
        if (root == null)  return root; 
        int k=key.compareTo((String) root.key);
        
        if (k<0) 
            root.left = deleteRec(root.left, key); 
        else if (k>0) 
            root.right = deleteRec(root.right, key); 
  
        else
        { 
            
            if (root.left == null) 
                return root.right;
            else if (root.right == null) 
                return root.left; 
  
            root.key = minValue(root.right); 
 
            root.right = deleteRec(root.right, (String) root.key); 
        } 
  
        return root; 
    } 
  
    String minValue(TreeNode root) 
    { 
        String minv = (String) root.key; 
        while (root.left != null) 
        { 
            minv = (String) root.left.key; 
            root = root.left; 
        } 
        return minv; 
    } 
   
   
    public Object get( String key) {
		return (Object)  get(root,key);
	}
	
	public Object get(TreeNode x, String key) { 
	if (x == null) {
		
		return null;}
	int cmp =key.compareTo((String) x.key) ;  
	if (cmp < 0) 
	return get(x.left, key);     
	else if (cmp > 0) 
	return get(x.right, key);   
	else return (Object) x.value; 
	
	}
}
public class BSTDictionary  implements DictionaryInterface 
{
	BST b=new BST();
	@Override
	public String[] getKeys() {
		// TODO Auto-generated method stub
		b.inorderbe();
		return (String[]) b.inorderbe();
	}

	@Override
	public Object getValue(String str) {
		// TODO Auto-generated method stub
		return (Object) b.get(str);
	}

	@Override
	public void insert(String key, Object value) {
		// TODO Auto-generated method stub
		b.count++;
		b.insert(key, value);
		
	}

	@Override
	public void remove(String key) {
		b.count--;
		// TODO Auto-generated method stub
		b.deleteKey(key);
		
	}



}



