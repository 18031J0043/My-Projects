package searchengine.dictionary;

import java.util.ArrayList;
import java.util.Vector;

class HashNode 
{
    String key;
    Object value;
    
    public HashNode(String key, Object value )
    {
    	this.key=key;
    	this.value=value;
    }
}   


public class MyHashDictionary  implements DictionaryInterface 
{
	
	HashNode[] a= new HashNode[1000];
	int count=0;
	@Override
	public String[] getKeys() {
		// TODO Auto-generated method stub
		
		String ar[]=new String[count];
		int i=0;
		for(int j=0;j<a.length;j++)
		{
			if(a[j]!=null &&a[j].key!=null)
			{
				ar[i]=(String) a[j].key;
				i++;
			}
		}
		
		return (String[]) ar;
	}

	@Override
	public Object getValue(String str) {
		// TODO Auto-generated method stub
		int id=hashcode(str);
		return (Object) a[id].value;
	}

	@Override
	public void insert(String key, Object value) {
		// TODO Auto-generated method stub
		HashNode hn=new HashNode(key,value);
		int ind=hashcode(key);
		if(a[ind]==null)
		{
			count++;
		}
		a[ind]=hn;
		
	}

	@Override
	public void remove(String key) {
		// TODO Auto-generated method stub
		int ind=hashcode(key);
		a[ind]=null;
		count--;
	}

	public int hashcode(String key)
	{
		String ab=(String) key;
		int sum=0;
		for(int i=0;i<ab.length();i++)
		{
			sum=sum+(ab.charAt(i)*(i+1));
		}
		sum=sum% a.length;
		return sum;
	}
}
