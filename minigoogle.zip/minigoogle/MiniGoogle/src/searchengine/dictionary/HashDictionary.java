package searchengine.dictionary;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;

public class HashDictionary  implements DictionaryInterface 
{
	Hashtable<String,Object> h=new Hashtable<String,Object>();

	@Override
	public String[] getKeys() {
		Iterator<String> m= (Iterator<String>) h.keys();
		// TODO Auto-generated method stub
	String aa[]=new String[h.size()];int i=0;
	while(m.hasNext())
	{
		aa[i]=(String) m.next();
	}
		return (String[]) aa;
	}

	@Override
	public Object getValue(String str) 
	{
	
		return h.get(str);
	}

	@Override
	public void insert(String key, Object value) {
		// TODO Auto-generated method stub
		h.put(key, value);
	}

	@Override
	public void remove(String key) {
		// TODO Auto-generated method stub
		h.remove(key);
	}

}
