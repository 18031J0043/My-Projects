package searchengine.element;

public class PageIframe implements PageElementInterface {

	public PageIframe (String h) /* perhaps throw an invalid filename error? */{
		Iframe = h;
	}

	public String toString () {
		return Iframe;
	}

	private String Iframe;
}

