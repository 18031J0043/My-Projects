package searchengine.element;

public class PageFrame implements PageElementInterface {

	public PageFrame (String h) /* perhaps throw an invalid filename error? */{
		Frame = h;
	}

	public String toString () {
		return Frame;
	}

	private String Frame;
}


